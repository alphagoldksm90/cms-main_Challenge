package com.zerobase.cms.domain.domain.common;

public enum UserType {
    CUSTOMER,
    SELLER;
}
